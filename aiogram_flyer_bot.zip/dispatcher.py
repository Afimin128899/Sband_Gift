from aiogram import Dispatcher

dp = Dispatcher()
