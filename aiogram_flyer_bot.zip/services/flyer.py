from flyerapi import Flyer
from config import FLYER_API_KEY

flyer = Flyer(FLYER_API_KEY)
